package poly.edu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Ts00999Lab3NgocHanApplication {

	public static void main(String[] args) {
		SpringApplication.run(Ts00999Lab3NgocHanApplication.class, args);
	}

}
//Bài 1 – Staff Detail
//👉 http://localhost:8080/staff/detail
//
//Bài 2 – Danh sách Staff
//👉 http://localhost:8080/staff/list
//
//Bài 4 – List Status
//👉 http://localhost:8080/staff/list-status
//
//Bài 5 – SelectBox + Radio Group
//👉 http://localhost:8080/staff/list-controls
